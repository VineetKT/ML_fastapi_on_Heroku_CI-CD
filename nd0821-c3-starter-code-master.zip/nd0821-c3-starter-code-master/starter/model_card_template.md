# Model Card

For additional information see the Model Card paper: https://arxiv.org/pdf/1810.03993.pdf

## Model Details

## Intended Use

## Training Data

## Evaluation Data

## Metrics

## Ethical Considerations

## Caveats and Recommendations
